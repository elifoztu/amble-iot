const { initializeApp } = require('firebase/app');
const {
    getAuth,
    signInWithEmailAndPassword
} = require('firebase/auth');

const {
    getDatabase,
    ref,
    onValue,
    get
} = require('firebase/database');

const { exec, spawn } = require('child_process');

let discoProcess = null;

// =========================
// Firebase config
// =========================
const firebaseConfig = {
    apiKey: "AIzaSyAwftLGn3PIuWMm1KxPFuG3XJEq69RPIxQ",
    authDomain: "amble-bfa94.firebaseapp.com",
    databaseURL: "https://amble-bfa94-default-rtdb.firebaseio.com",
    projectId: "amble-bfa94",
    storageBucket: "amble-bfa94.firebasestorage.app",
    messagingSenderId: "765015893097",
    appId: "1:765015893097:web:d24ffa4a090ed8d023aef8",
    measurementId: "G-EG5MBM5YH6"
};

const app = initializeApp(firebaseConfig);
const database = getDatabase(app);
const auth = getAuth(app);

// =========================
// SPI / LED strip setup
// =========================
const SPI = require('pi-spi');
const dotstar = require('dotstar');

const spi = SPI.initialize('/dev/spidev0.0');
const ledCount = 60;

const strip = new dotstar.Dotstar(spi, {
    length: ledCount
});

// =========================
// Watch current vibe
// =========================
function watchVibeAndUpdateLight() {
    const vibeRef = ref(database, "lamp/current_vibe");

    console.log("Listening for changes to lamp/current_vibe...");

    onValue(vibeRef, async (snapshot) => {
        try {
            if (!snapshot.exists()) {
                console.log("No current_vibe data found.");
                return;
            }

            const vibe = snapshot.val();

            const rgbRef = ref(database, `vibes/${vibe}`);
            const rgbSnap = await get(rgbRef);

            if (!rgbSnap.exists()) {
                console.log(`No RGB found for vibe "${vibe}"`);
                return;
            }

            const { r, g, b } = rgbSnap.val();

            if (vibe === "party") {
                console.log("Party mode activated: running Disco.js");

                if (discoProcess) {
                    discoProcess.kill('SIGTERM');
                    discoProcess = null;
                }

                discoProcess = spawn('node', ['Disco.js']);

                discoProcess.stdout.on('data', (data) => {
                    console.log(`Disco.js stdout: ${data}`);
                });

                discoProcess.stderr.on('data', (data) => {
                    console.error(`Disco.js stderr: ${data}`);
                });

                discoProcess.on('close', (code) => {
                    console.log(`Disco.js exited with code ${code}`);
                    discoProcess = null;
                });

            } else {
                if (discoProcess) {
                    discoProcess.kill('SIGTERM');
                    discoProcess = null;
                }
            }

            strip.all(r, g, b, 1);
            strip.sync();

            console.log(`Current vibe changed to: ${vibe}`);
            console.log(`RGB -> R:${r} G:${g} B:${b}`);

        } catch (error) {
            console.error("Error handling vibe update:", error);
        }
    });
}

// =========================
// Watch fan
// =========================
function watchFan() {
    const fanRef = ref(database, "lamp/fan");

    console.log("Listening for changes to lamp/fan...");

    onValue(fanRef, (snapshot) => {
        try {
            if (!snapshot.exists()) {
                console.log("No fan data found.");
                return;
            }

            const fanState = snapshot.val();

            if (fanState === true) {
                exec('python3 fan_on.py');
            } else if (fanState === false) {
                exec('python3 fan_off.py');
            } else {
                console.log("Fan value is not a boolean:", fanState);
            }

        } catch (error) {
            console.error("Error handling fan update:", error);
        }
    });
}

// =========================
// Watch motor
// =========================
function watchMotor() {
    const motorRef = ref(database, "lamp/motor");

    console.log("Listening for changes to lamp/motor...");

    onValue(motorRef, (snapshot) => {
        try {
            if (!snapshot.exists()) {
                console.log("No motor data found.");
                return;
            }

            const motorState = snapshot.val();

            if (motorState === true) {
                exec('python3 fanSweep.py');
            } else if (motorState === false) {
                exec('python3 motor_stop.py');
            } else {
                console.log("Motor value is not a boolean:", motorState);
            }

        } catch (error) {
            console.error("Error handling motor update:", error);
        }
    });
}

// =========================
// Sign in first, then start AMBLE
// =========================
async function startAMBLE() {
    try {
        const email = process.env.AMBLE_FIREBASE_EMAIL;
        const password = process.env.AMBLE_FIREBASE_PASSWORD;

        if (!email || !password) {
            console.error("Missing Firebase login info.");
            console.error("Run these first:");
            console.error('export AMBLE_FIREBASE_EMAIL="your-email"');
            console.error('export AMBLE_FIREBASE_PASSWORD="your-password"');
            return;
        }

        console.log("Signing into Firebase...");

        await signInWithEmailAndPassword(auth, email, password);

        console.log("Firebase login successful.");

        watchVibeAndUpdateLight();
        watchFan();
        watchMotor();

    } catch (error) {
        console.error("Firebase login failed:", error.message);
    }
}

// =========================
// Clean shutdown
// =========================
process.on('SIGINT', () => {
    console.log("\nShutting down...");
    process.exit();
});

startAMBLE();